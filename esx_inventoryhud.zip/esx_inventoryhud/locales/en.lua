Locales['en'] = {
	['cash'] = 'Cash',
	['black_money'] = 'Dirty Money',
	['player_nearby'] = 'Player nearby!',
	['players_nearby'] = 'Players nearby!'
}