var invLocale = new Object();
invLocale.dropItem = "Zahodit";
invLocale.useItem = "Použít";
invLocale.giveItem = "Dát";
invLocale.secondInventoryNotAvailable = "Druhý inventář není dostupný";